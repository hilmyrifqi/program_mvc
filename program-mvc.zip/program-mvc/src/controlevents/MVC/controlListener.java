/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package controlevents.MVC;

/**
 *
 * @author resa c.r
 */
import model.MVC.modelUtama;

public interface controlListener 
{
    public void Tampilkan(modelUtama mu);
}
